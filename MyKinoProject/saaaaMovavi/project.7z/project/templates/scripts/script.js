$("button").click(function() {
    console.log($(this).attr("id"))
})
