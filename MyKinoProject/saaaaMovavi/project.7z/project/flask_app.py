
# A very simple Flask Hello World app for you to get started with...

from flask import Flask, request, render_template, redirect,session
import random
import json
import sqlite3

app = Flask(__name__)
app.secret_key = 'qas8iytfrdcchgvbnmkhgvuygfcvbhyfdxcfdcvjnb'

@app.route("/")
def index():
    j = []
    a = random.randint(1, 100)
    for i in range(random.randint(0, a)):
        s = random.randint(0, a)
        j.append(s)
    return render_template('index.html', data = [a, j])



if __name__ == '__main__':
    app.run(port=3301)
